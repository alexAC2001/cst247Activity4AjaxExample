﻿$(function () {
    console.log("Page is ready");

    // When a radio button is click
    $(".customerRadio").click(function () {
        console.log("select customer button was clicked");
        doCustomerUpdate();
    });

    // When the Submit button is clicked
    $("#selectCustomer").click(function (event) {
        event.preventDefault();
        console.log("select customer button was clicked");
        doCustomerUpdate();
    });

    function doCustomerUpdate() {
        $.ajax({
            datatype: "text/plain",
            url: 'customer/ShowOnePerson',
            data: $("form").serialize(),
            success: function (data) {
                console.log(data);
                // Replaces a region on the page with the data sent back from the controller
                $("#customerInformationArea").html(data);
            }
        });
    };
});
