﻿using AJAXExample.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AJAXExample.Controllers
{
    public class CustomerController : Controller
    {
        // New list of CustomerModels referenced by customers
        List<CustomerModel> customers = new List<CustomerModel>();

        // Constructor
        public CustomerController()
        {
            customers.Add(new CustomerModel(0, "Sherry", 42));
            customers.Add(new CustomerModel(1, "Melvin", 18));
            customers.Add(new CustomerModel(2, "Jerry", 26));
            customers.Add(new CustomerModel(3, "Velma", 34));
            customers.Add(new CustomerModel(4, "Wendy", 7));
            customers.Add(new CustomerModel(5, "Kim", 82));
        }

        // Index method
        public IActionResult Index()
        {
            return View(customers);
        }

        // ShowOnePerson method when button is clickedS
        public IActionResult ShowOnePerson(int Id)
        {
            // c i s aC# linq function that selects the first item in the customers list whose Id property matches with the ?
            //return View(customers.FirstOrDefault( c => c.Id == Id));
            return PartialView(customers.FirstOrDefault(customers => customers.Id == Id));
        }

    }
}
